let rotulo = document.getElementById("rotulo") as HTMLParagraphElement;
let btnCheck = document.getElementById("btnCheck") as HTMLButtonElement;

rotulo.innetHTML = "even or odd?";

btnCheck.addEventListener("click", () => {
  let userNum: number = prompt("Enter a number: (positive)");
  while (userNum <= 0) {
    userNum = prompt("Try again:");
  }
  if (userNum % 2 === 0) {
    console.log("CONGRATS!!! Your num is even ;)");
  } else {
    console.log("CONGRATS!!! Your number is odd ;)");
  }
});

//Agregar typeof para que no te tome valores String.
